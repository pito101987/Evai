const express = require("express");
const path = require("path");
const dotenv = require("dotenv");
const cors = require("cors");
const OpenAI = require("openai");

dotenv.config();

const app = express();
const PORT = process.env.PORT || 3000;

app.use(cors());
app.use(express.json());
app.use(express.static(path.join(__dirname, "public")));

// Initialize OpenAI client
const client = new OpenAI({ apiKey: process.env.OPENAI_API_KEY });

// Health check
app.get("/api/health", (req, res) => {
  res.json({ ok: true, service: "EVAI MVP", time: new Date().toISOString() });
});

// Chat endpoint
app.post("/api/chat", async (req, res) => {
  try {
    const { message, system } = req.body || {};
    if (!message || typeof message !== "string") {
      return res.status(400).json({ error: "Missing 'message' string in body." });
    }

    const response = await client.chat.completions.create({
      model: "gpt-4o-mini",
      messages: [
        { role: "system", content: system || "You are EVAI, a friendly, motivating assistant that answers clearly and concisely." },
        { role: "user", content: message }
      ],
      temperature: 0.7
    });

    const text = response.choices?.[0]?.message?.content ?? "";
    res.json({ reply: text });
  } catch (err) {
    console.error("Chat error:", err?.response?.data || err.message || err);
    res.status(500).json({ error: "Chat failed", detail: err?.message || String(err) });
  }
});

app.listen(PORT, () => {
  console.log(`EVAI MVP listening on http://localhost:${PORT}`);
});
