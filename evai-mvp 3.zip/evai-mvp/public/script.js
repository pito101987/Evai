const $ = (id) => document.getElementById(id);
const messages = $("messages");
const input = $("input");
const send = $("send");
const system = $("system");

function add(role, text) {
  const div = document.createElement("div");
  div.className = "msg " + (role === "user" ? "user" : "ai");
  div.textContent = text;
  messages.appendChild(div);
  messages.scrollTop = messages.scrollHeight;
}

async function ask() {
  const text = input.value.trim();
  if (!text) return;
  input.value = "";
  add("user", text);
  send.disabled = true;

  try {
    const res = await fetch("/api/chat", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ message: text, system: system.value.trim() || undefined })
    });
    const data = await res.json();
    if (data.reply) add("ai", data.reply);
    else add("ai", "No reply (check server).");
  } catch (e) {
    add("ai", "Error: " + e.message);
  } finally {
    send.disabled = false;
    input.focus();
  }
}

send.addEventListener("click", ask);
input.addEventListener("keydown", (e) => {
  if (e.key === "Enter" && !e.shiftKey) ask();
});
