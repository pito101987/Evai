# EVAI MVP (Node + Express + OpenAI)

Minimal full‑stack starter you can run locally and deploy to Render/Vercel/Fly.io.

## 1) Prereqs
- Node.js 18+
- An OpenAI API key

## 2) Setup
```bash
npm install
cp .env.example .env
# edit .env and paste your API key
npm run start
```

Visit: http://localhost:3000

## 3) Env
Create `.env` with:
```env
OPENAI_API_KEY=sk-...
```

## 4) Deploy (Render quick notes)
- Create a new **Web Service**
- Runtime: Node
- Build command: `npm install`
- Start command: `npm start`
- Add environment variable: `OPENAI_API_KEY`
- Auto‑deploy from your GitHub repo

## 5) Customize
- Change the model in `server.js` (e.g., `gpt-4o`, `gpt-4.1-mini`, etc.)
- Update `public/index.html` UI / `public/script.js` behavior
- Add routes (e.g., `/api/vision`, `/api/tools`) as you grow EVAI
